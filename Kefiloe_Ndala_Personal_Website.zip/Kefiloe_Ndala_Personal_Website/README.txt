KEFILOЕ NDALA — PERSONAL PORTFOLIO

PREVIEW
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, Firefox or another browser.

EDIT
Open index.html in a text editor (for example, Notepad or VS Code).
You can change the wording, colours and sections.

PUBLISH FOR FREE WITH GITHUB PAGES
1. Create an account at https://github.com/
2. Create a public repository named YOURUSERNAME.github.io
3. Upload index.html to the repository's root folder.
4. Open Settings > Pages and enable publishing from the main branch.
5. Your site should appear at https://YOURUSERNAME.github.io/

BEFORE PUBLISHING
Review every personal detail. Add only projects you have genuinely completed.
Your email address is displayed publicly on the site; remove it if you prefer not to publish it.
